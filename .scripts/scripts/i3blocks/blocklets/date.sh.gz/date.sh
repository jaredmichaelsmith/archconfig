#!/bin/sh
#~/scripts/i3blocks/blocklets/date.sh

date '+%a %b %d, %Y'
