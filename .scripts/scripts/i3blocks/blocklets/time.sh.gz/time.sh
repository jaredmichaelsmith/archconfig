#!/bin/bash
#~/scripts/i3blocks/blocklets/time.sh

date '+%H:%M:%S'


